# apd-detection > 2025-12-21 12:13pm
https://universe.roboflow.com/azkada/apd-detection-jtwtx

Provided by a Roboflow user
License: CC BY 4.0

